IRFAN GOLD ALARM BOT — PWA package

Deployment:
1. Upload all files in this folder to a GitHub repository root.
2. In GitHub repository Settings → Pages, set deployment source to Deploy from a branch.
3. Choose branch main and folder /(root), then Save.
4. Wait for GitHub Pages to publish the HTTPS site.
5. Open the published HTTPS URL in Chrome on Android → ⋮ → Install app / Add to Home screen.

Important:
- A PWA requires HTTPS hosting. A downloaded content:// HTML file cannot be installed as a PWA.
- The TradingView chart and market feed require internet and may differ from Blue Guardian MT5 quotes.
- The page must remain open for the current in-page price/strategy alarms; this package does not implement background push alerts.
